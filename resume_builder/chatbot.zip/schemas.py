from pydantic import BaseModel
from fastapi import UploadFile, Form, File


class Query(BaseModel):

    job_posting_url: str
    github_url: str
    personal_writeup: str
    resume_file: UploadFile

    @classmethod
    def as_form(
            cls,
            job_posting_url: str = Form(...),
            github_url: str = Form(...),
            personal_writeup: str = Form(...),
            resume_file: UploadFile = File(...),
    ):
        return cls(
            job_posting_url=job_posting_url,
            github_url=github_url,
            personal_writeup=personal_writeup,
            resume_file=resume_file
        )

    def pop(self, field):
        if hasattr(self, field):
            value = getattr(self, field)
            delattr(self, field)
            return value
        raise AttributeError("Field `%s` doesn't exist" % field)

