from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent

TEMP_DIR = BASE_DIR / 'assets/tmp'
DOWNLOADS_DIR = BASE_DIR / 'assets/export'